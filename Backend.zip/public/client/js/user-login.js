$(document).ready(function() {
    $('#email').change(function(e) {
        $('.error-login').hide();
        $('.register-success').hide();
    });
});