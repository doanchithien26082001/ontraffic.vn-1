<?php

namespace App\View\Components;

use App\Support;

use Illuminate\View\Component;

class SupportType extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\View\View|string
     */
    public function render()
    {
        $allCount = Support::all();
        $penddingCount = Support::where('status', 'Chờ hỗ trợ')->count();
        $progressCount = Support::where('status', 'Đang hỗ trợ')->count();
        $completedCount = Support::where('status', 'Đã hỗ trợ')->count();
        return view('components.support-type', compact('allCount', 'penddingCount', 'progressCount', 'completedCount'));
    }
}
