<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupportType extends Model
{
    protected $table = 'support_types';
    protected $fillable = [
        'name',
    ];
}
