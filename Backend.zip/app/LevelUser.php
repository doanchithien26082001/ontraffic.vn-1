<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LevelUser extends Model
{
    protected $table = 'levels';
    protected $fillable = [
        'level_name', 'hook','discount'
    ];
}
