<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TrafficController extends Controller
{
    function createTrafficOrganic()
    {
        return view('users.create-traffic-organic');
    }
    function createTrafficBaclink()
    {
        return view('users.create-traffic-backlink');
    }
    function createTrafficDirect()
    {
        return view('users.create-traffic-direct');
    }
    function createTrafficClick()
    {
        return view('users.create-traffic-click');
    }
}
