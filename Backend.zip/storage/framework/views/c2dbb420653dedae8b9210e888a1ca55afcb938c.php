
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('client/css/uploadfile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('client/css/traffic.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <span class="nav-link home d-flex align-content-center"><a href="<?php echo e(route('userDashboard')); ?>"><i
                    class="bi bi-house-fill"></i> <span>Hệ thống</span></a>
        </span>
        <span class="nav-link d-flex align-content-center"><a href="<?php echo e(route('userPayment')); ?>"><i
                    class="bi bi-caret-right-fill center"></i> <span>Nạp tiền</span></a>
        </span>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row gx-3 no-reverse">
        <div class="col-12 col-md-6 col-lg-7">
            <div class="card shadow mb-3">
                <div class="card-body">
                    <div
                        class="title-traffic shadow-sm card-body bd-style-2 mb-2 d-flex justify-content-between align-items-center">
                        <h2 class="title-section mb-0 text-dark mb-0">Tạo Traffic Click</h2>
                        <a href="" class="btn btn-primary"><i class="bi bi-graph-up icon-item"></i> Quản lý tiến
                            trình</a>
                    </div>
                    <form action="" class="form">
                        <div class="form-group shadow-sm card-body bd-style-2 mb-1">
                            <label for="" class="form-label fw-bold">Từ khoá (top 10 - 1 trang nhất)</label>
                            <textarea name="" placeholder="Nhập mỗi từ khoá trên 1 dòng" class="form-control" id="" cols="30"
                                rows="10"></textarea>
                        </div>
                        <div class="form-group shadow-sm card-body bd-style-2 mb-1">
                            <label for="" class="form-label fw-bold">Trang web cần redirect trỏ tới (nhập chính xác
                                url)</label>
                            <input type="text" class="form-control bd-style-2" placeholder="Nhập chính xác">
                        </div>
                        <div class="form-group shadow-sm card-body bd-style-2 mb-1 upload-file">
                            <input type="file" class="files" multiple max="4">
                            <div class="d-flex justify-content-between align-items-center">
                                <label for="" class="form-label mb-0 fw-bold">Thêm ảnh mô tả (click vảo ảnh để
                                    xoá)</label>
                                <span class="btn btn-primary upload"><i class="bi bi-cloud-arrow-up-fill"></i> Tải ảnh
                                    lên</span>
                            </div>
                            <div class="image-list"></div>
                        </div>
                        <div class="form-group shadow-sm card-body bd-style-2 mb-1">
                            <div class="row">
                                <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                    <label for="" class="form-label fw-bold">Số traffic/ngày (min 240, max
                                        30.000)</label>
                                    <input type="text" class="form-control bd-style-2"
                                        placeholder="Nhập Url trang đích muốn chạy trafic" value="240">
                                </div>
                                <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                    <label for="" class="form-label fw-bold">Tổng số trafic mua ( min 500 )</label>
                                    <input type="text" class="form-control bd-style-2"
                                        placeholder="Nhập Url trang đích muốn chạy trafic" value="500">
                                </div>
                            </div>
                        </div>
                        <div class="form-group shadow-sm card-body bd-style-2 mb-1">
                            <div class="row">
                                <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                    <label for="" class="form-label fw-bold">Time onsite</label>
                                    <select class="form-select bd-style-2 select-url" aria-label="Default select example ">
                                        <option selected value="1"> > 30s</option>
                                        <option value="1 "> > 60s</option>
                                        <option value="2 "> > 90s</option>
                                        <option value="3 "> > 120s</option>
                                    </select>
                                </div>
                                <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                    <label for="" class="form-label fw-bold">Giá gói</label>
                                    <input type="text" class="form-control bd-style-2"
                                        placeholder="Nhập Url trang đích muốn chạy trafic" value="990 Coin">
                                </div>
                            </div>
                        </div>
                        <div class="form-group shadow-sm card-body bd-style-2 mb-1">
                            <div class="row">
                                <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                    <label for="" class="form-label fw-bold">Chọn thiết bị</label>
                                    <div class="row">
                                        <div class="custom-control custom-checkbox col-auto">
                                            <input type="checkbox" class="custom-control-input" checked id="customCheck1">
                                            <label class="custom-control-label" for="customCheck1">Mobile</label>
                                        </div>
                                        <div class="custom-control custom-checkbox col-auto">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1">
                                            <label class="custom-control-label" for="customCheck1">PC</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 mb-2 mb-lg-0">
                                    <label for="" class="form-label fw-bold">Số điện thoại</label>
                                    <input type="text" class="form-control bd-style-2"
                                        placeholder="Liên hệ khi có sự cố">
                                </div>
                            </div>
                        </div>
                        <div class="form-group shadow-sm card-body bd-style-2 mb-1">
                            <span class="fw-bold text-primary text-center d-block">Tổng: <span
                                    class="text-success h5">900,000 Coin</span></span>
                            <span class="fw-bold text-primary text-center d-block">Bạn sẽ buff <span
                                    class="text-success">1,000 traffic</span> với giá <span class="text-success"> 900 Coin
                                    / traffic<span></span>
                        </div>
                        <div class="form-group shadow-sm card-body bd-style-2">
                            <button class="btn btn-primary w-100">Tạo tiến trình</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-5">
             <?php if (isset($component)) { $__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Report::class, []); ?>
<?php $component->withName('report'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e)): ?>
<?php $component = $__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e; ?>
<?php unset($__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Note::class, []); ?>
<?php $component->withName('note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd)): ?>
<?php $component = $__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd; ?>
<?php unset($__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Contact::class, []); ?>
<?php $component->withName('contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed)): ?>
<?php $component = $__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed; ?>
<?php unset($__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TutorialPayment::class, []); ?>
<?php $component->withName('tutorial-payment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c)): ?>
<?php $component = $__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c; ?>
<?php unset($__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/client/js/uploadfile.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Backend\resources\views/users/create-traffic-click.blade.php ENDPATH**/ ?>