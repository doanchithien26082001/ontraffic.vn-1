<img src="<?php echo e(asset('/client/images/user.png')); ?>" alt="" class="user-avatar">
<div class="wp-block">
    <p class="text-left mb-0 info-username text-dark"><strong><?php echo e(Auth::user()->name); ?></strong></p>
    <p class="text-left mb-0 num-coin text-success"><span class="coin"><?php echo e($userCoin); ?> Coin</span></p>
</div>
<?php /**PATH C:\xampp\htdocs\Backend\resources\views/components/info-user01.blade.php ENDPATH**/ ?>