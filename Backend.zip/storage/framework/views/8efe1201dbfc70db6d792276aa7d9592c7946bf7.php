<ul class="list-posts-02 row px-2">
    <li class="mb-3 card shadow-sm p-3 col-12 col-md-4">
        <a href="" class="thumbnail d-block">
            <img src="<?php echo e(asset('client/images/avt-post.jpg')); ?>" alt=""
                class="img-fluid">
        </a>
        <div class="wp-info">
            <a href="" class="post-cat d-block mt-1">#Giới thiệu</a>
            <a href="" class="post-title d-block">Giới thiệu về ontraffic.vn</a>
        </div>
    </li>
    <li class="mb-3 card shadow-sm p-3 col-12 col-md-4">
        <a href="" class="thumbnail d-block">
            <img src="<?php echo e(asset('client/images/digital-bill-2042861-1729019.png')); ?>"
                alt="" class="img-fluid">
        </a>
        <div class="wp-info">
            <a href="" class="post-cat d-block mt-1">#Hướng dẫn</a>
            <a href="" class="post-title d-block">Hướng dẫn quy trình thanh toán các sản
                phẩm tại ontraffic.vn</a>
        </div>
    </li>
    <li class="mb-3 card shadow-sm p-3 col-12 col-md-4">
        <a href="" class="thumbnail d-block">
            <img src="<?php echo e(asset('client/images/Wordpress-Plugins-4.png')); ?>" alt=""
                class="img-fluid">
        </a>
        <div class="wp-info">
            <a href="" class="post-cat d-block mt-1">#Hướng dẫn</a>
            <a href="" class="post-title d-block">Hướng dẫn tích hợp plugin run traffic
                trên website wordpress</a>
        </div>
    </li>
</ul><?php /**PATH C:\xampp\htdocs\Backend\resources\views/components/list-post02.blade.php ENDPATH**/ ?>