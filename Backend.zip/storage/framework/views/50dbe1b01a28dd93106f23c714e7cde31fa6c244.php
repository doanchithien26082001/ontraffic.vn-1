<div class="card shadow-sm mb-3">
    <div class="card-body">
        <div class="header-notication d-flex justify-content-between align-items-center mb-3">
            <h2 class="title-section mb-0">Liên hệ hỗ trợ nóng</h2>
        </div>
        <ul>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Zalo: <a
                    href="">0942342090</a></li>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Messenger: <a
                    href="">Link messenger</a></li>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Telegrame: <a
                    href="">Link telegrame</a></li>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Hotline: <a
                    href="">0948234723</a></li>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Backend\resources\views/components/contact.blade.php ENDPATH**/ ?>