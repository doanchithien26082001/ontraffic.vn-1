<p class="mb-1"><strong>Tỷ giá 1 VND = 1 Coin</strong></p>
<p class="mb-1"><i class="bi bi-arrow-right-circle-fill"></i> Bạn vui lòng chuyển
    khoản chính xác nội dung chuyển khoản bên dưới hệ thống sẽ tự động cộng tiền cho bạn
    sau 1 phút sau khi nhận được tiền.</p>
<p class="mb-1"><i class="bi bi-arrow-right-circle-fill"></i> Nếu chuyển khác ngân
    hàng sẽ mất thời gian lâu hơn, tùy thời gian xử lý của mỗi ngân hàng. Nếu sau 10
    phút từ khi tiền trong tài khoản của bạn bị trừ mà vẫn
    chưa được cộng tiền vui lòng liên hệ hỗ trợ.</p>
<p class="mb-1"><strong class="text-danger"><i class="bi bi-arrow-right-circle-fill"></i> Sau khi nạp tiền vui lòng
        refresh
        lại trang để xem tiền đã vào chưa trước khi nạp lệnh mới</strong></p>
<?php /**PATH C:\xampp\htdocs\Backend\resources\views/components/text-payment.blade.php ENDPATH**/ ?>