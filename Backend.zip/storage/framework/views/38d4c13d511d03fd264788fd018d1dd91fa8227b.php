<ul class="list-posts-01">
    <li class="mb-3 card shadow-sm p-3">
        <a href="" class="thumbnail d-block">
            <img src="<?php echo e(asset('client/images/avt-post.jpg')); ?>" alt="">
        </a>
        <div class="wp-info">
            <a href="" class="post-cat d-block mt-1">#Giới thiệu</a>
            <a href="" class="post-title d-block">Giới thiệu về ontraffic.vn</a>
        </div>
    </li>
    <li class="mb-3 card shadow-sm p-3">
        <a href="" class="thumbnail d-block">
            <img src="<?php echo e(asset('client/images/digital-bill-2042861-1729019.png')); ?>" alt="">
        </a>
        <div class="wp-info">
            <a href="" class="post-cat d-block mt-1">#Hướng dẫn</a>
            <a href="" class="post-title d-block">Hướng dẫn quy trình thanh toán các sản
                phẩm tại ontraffic.vn</a>
        </div>
    </li>
    <li class="mb-3 card shadow-sm p-3">
        <a href="" class="thumbnail d-block">
            <img src="<?php echo e(asset('client/images/Wordpress-Plugins-4.png')); ?>" alt="">
        </a>
        <div class="wp-info">
            <a href="" class="post-cat d-block mt-1">#Hướng dẫn</a>
            <a href="" class="post-title d-block">Hướng dẫn tích hợp plugin run traffic
                trên website wordpress</a>
        </div>
    </li>
</ul><?php /**PATH C:\xampp\htdocs\Backend\resources\views/components/list-post01.blade.php ENDPATH**/ ?>