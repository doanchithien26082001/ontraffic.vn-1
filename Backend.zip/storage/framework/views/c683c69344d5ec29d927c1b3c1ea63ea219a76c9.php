<div class="wp-moblie-menu p-3">
    <div class="text-center pt-3 pb-2">
        <img src="<?php echo e(asset('/client/images/user.png')); ?>" alt="" class="user-avatar">
    </div>
    <div class="wp-block text-center">
        <p class="mb-0 info-username text-dark"><strong><?php echo e(Auth::user()->name); ?></strong></p>
        <p class="mb-0 num-coin text-success"><span class="coin"><?php echo e($userCoin); ?> Coin</span></p>
        <p class="mb-0 level-user btn btn-primary w-100 my-3">Cấp đại lý: Khách hàng</p>
    </div>
    <ul class="moblie-menu p-2">
         <?php if (isset($component)) { $__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuUser::class, []); ?>
<?php $component->withName('menu-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8)): ?>
<?php $component = $__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8; ?>
<?php unset($__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </ul>
</div><?php /**PATH C:\xampp\htdocs\Backend\resources\views/components/mobile-menu.blade.php ENDPATH**/ ?>