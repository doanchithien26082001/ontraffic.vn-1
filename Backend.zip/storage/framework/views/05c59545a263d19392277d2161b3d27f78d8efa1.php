<div class="card shadow mb-3">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="title-section mb-0">Cấp bậc đại lý</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-hover table-bordered table-sm level">
                <thead>
                    <tr>
                        <th class="text-center align-middle text-no-wrap">Level</th>
                        <th class="text-center align-middle text-no-wrap">Tổng nạp</th>
                        <th class="text-center align-middle text-no-wrap">Chiết khấu (%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dataLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center align-middle text-no-wrap"><?php echo e($item->level_name); ?></td>
                            <td class="text-center align-middle text-no-wrap">
                                <?php echo e(number_format($item->hook, 0, ',', '.')); ?> đ</td>
                            <td class="text-center align-middle text-no-wrap"><?php echo e($item->discount); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Backend\resources\views/components/level.blade.php ENDPATH**/ ?>