<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('client/css/user-login.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('form'); ?>
    <form id="register-form" class="form-horizontal form-material form-auth-user" method="POST"
        action="<?php echo e(route('userHandleRegister')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-3">
            <input placeholder="Tên tài khoản" id="name" type="text"
                class="form-control form-control-lg input-light border-0 border-0 bd-style-2 py-1" name="name"
                value="<?php echo e(old('name')); ?>" required autocomplete="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i class="bi bi-exclamation-circle-fill"></i>
                    <?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mt-3">
            <input placeholder="Email" id="email" type="email"
                class="form-control form-control-lg input-light border-0 border-0 bd-style-2 py-1" name="email"
                value="<?php echo e(old('email')); ?>" required autocomplete="email">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i class="bi bi-exclamation-circle-fill"></i>
                    <?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mt-3 form-group-password">
            <input placeholder="Mật khẩu" id="password" type="password"
                class="form-control form-control-lg input-light border-0 border-0 bd-style-2 py-1" name="password" required
                autocomplete="new-password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i class="bi bi-exclamation-circle-fill"></i>
                    <?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <span class="toggle-show-password">
                <i class="bi bi-eye-fill"></i>
            </span>
        </div>
        <div class="form-group mt-3 form-group-password">
            <input placeholder="Xác nhận mật khẩu" id="password-confirm" type="password"
                class="form-control form-control-lg input-light border-0 border-0 bd-style-2 py-1"
                name="password_confirmation" required autocomplete="new-password">
            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i class="bi bi-exclamation-circle-fill"></i>
                    <?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <span class="toggle-show-password">
                <i class="bi bi-eye-fill"></i>
            </span>
        </div>
        <div class="form-group text-center my-3">
            <button type="submit" class="btn w-100 btn-primary border-0 bd-style-2 py-2">
                <span class="spinner-border spinner-border-sm d-none handle" role="status" aria-hidden="true"></span>
                <span class="text-button">Đăng ký</span>
            </button>
        </div>
        <div class="form-group my-4 text-center">
            <span>Đã có tài khoản? <a href="<?php echo e(route('userLogin')); ?>" class="text-green float-right font-bool"
                    id="to-login">Đăng nhập ngay</a></span>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Backend\resources\views/auth/register.blade.php ENDPATH**/ ?>