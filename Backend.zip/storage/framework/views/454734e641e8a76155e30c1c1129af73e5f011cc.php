
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('zoom-image.css')); ?>" />
    <style>
        .icon-report {
            padding: 14px 19px;
            border-radius: 10px;
            background: #9771df1a;
        }

        .icon-report i {
            font-size: 20px;
        }

        .report .wp-block {
            margin-left: 15px;
        }

        .report .wp-block .title-report {
            font-weight: 700;
        }

        .report .wp-block .desc-report {
            font-size: 14px;
            color: rgb(75 167 179);
        }

        .report .p-2.bd-style-2.d-flex {
            background: #92a3bd1a;
        }

        .qr-img {
            position: relative;
            height: auto;
            cursor: pointer;
        }

        .text-xs-copy {
            cursor: pointer;
        }

        .tooltip-ontraffic {
            position: fixed;
            display: inline-block;
            background-color: rgba(0, 0, 0, 1);
            color: white;
            top: 50%;
            left: 50%;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            z-index: 9999;
        }

        .tooltip-ontraffic::before {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            border-left: 10px solid rgba(0, 0, 0, 0);
            border-top: 10px solid rgba(0, 0, 0, 1);
            border-right: 10px solid rgba(0, 0, 0, 0);
        }

        @media(max-width:976px) {
            .icon-report {
                padding: 9px 7px;
            }
        }

        @media (max-width: 767px) {
            table.history td {
                padding: 5px 20px;
            }

            .page-content .content .payment.row {
                flex-direction: column;
            }
        }

        @media(max-width:600px) {

            .is-horizontal .fancybox__nav .f-button.is-prev,
            .is-horizontal .fancybox__nav .f-button.is-next {
                display: none;
            }
        }

        @media(max-width:365px) {
            .text-xs {
                display: inline-block;
                width: 100%;
            }

            .nav-link {
                padding: 0.2rem 0.5rem;
            }

            .tooltip-ontraffic {
                left: 0;
            }

            .report .wp-block {
                margin-left: 5px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <span class="nav-link home d-flex align-content-center"><a href="<?php echo e(route('userDashboard')); ?>"><i
                    class="bi bi-house-fill"></i> <span>Hệ thống</span></a>
        </span>
        <span class="nav-link d-flex align-content-center"><a href="<?php echo e(route('userPayment')); ?>"><i
                    class="bi bi-caret-right-fill center"></i> <span>Nạp tiền</span></a>
        </span>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row gx-3 payment">
        <div class="col-12 col-md-6 col-lg-7">
            <div class="card shadow mb-3">
                <div class="card-body">
                    <!-- Tab Nav -->
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="recharge-tab" data-bs-toggle="tab" href="#recharge"
                                        role="tab" aria-controls="recharge" aria-selected="true">Nạp tiền</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="history-tab" data-bs-toggle="tab" href="#history" role="tab"
                                        aria-controls="history" aria-selected="false">Lịch sử</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Tab Content -->
                    <div class="tab-content p2 mt-3" id="myTabContent">
                        <div class="tab-pane fade show active" id="recharge" role="tabpanel"
                            aria-labelledby="recharge-tab">
                            <div class="card shadow-sm">
                                <div class="card-body text-justify">
                                     <?php if (isset($component)) { $__componentOriginalb409ea54bfb6a3c90324c1960248a684360b2272 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextPayment::class, []); ?>
<?php $component->withName('text-payment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalb409ea54bfb6a3c90324c1960248a684360b2272)): ?>
<?php $component = $__componentOriginalb409ea54bfb6a3c90324c1960248a684360b2272; ?>
<?php unset($__componentOriginalb409ea54bfb6a3c90324c1960248a684360b2272); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </div>
                            </div>
                            <div class="row gx-2">
                                 <?php if (isset($component)) { $__componentOriginal5c9bccc0a1dbbd560307addd1f8b2b9d050fc606 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ListQr::class, []); ?>
<?php $component->withName('list-qr'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal5c9bccc0a1dbbd560307addd1f8b2b9d050fc606)): ?>
<?php $component = $__componentOriginal5c9bccc0a1dbbd560307addd1f8b2b9d050fc606; ?>
<?php unset($__componentOriginal5c9bccc0a1dbbd560307addd1f8b2b9d050fc606); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                        </div>
                        <div class="tab-pane fade" id="history" role="tabpanel" aria-labelledby="history-tab">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <div
                                        class="header-notication d-flex justify-content-between align-items-center mb-3 flex-wrap flex-md-nowrap">
                                        <h2 class="title-section mb-0">Lịch sử nạp tiền</h2>
                                        <input type="text" name="find-history" id="find-history"
                                            class="form-control bd-style-2 w-50 w-sm-100 mt-3 mt-sm-0"
                                            placeholder="Nhập id tìm kiếm">
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-hover history">
                                            <thead>
                                                <tr>
                                                    <th class="text-center align-middle text-no-wrap">Id nạp</th>
                                                    <th class="text-center align-middle text-no-wrap">Thời gian</th>
                                                    <th class="text-center align-middle text-no-wrap">Số tiền nạp</th>
                                                    <th class="text-center align-middle text-no-wrap">Tổng nạp</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if($transactionHistory->count() > 0): ?>
                                                    <?php $__currentLoopData = $transactionHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="text-center align-middle text-no-wrap">
                                                                <?php echo e($item->id_payment); ?></td>
                                                            <td class="text-center align-middle text-no-wrap">
                                                                <?php echo e(date('H:i d/m/Y', strtotime($item->created_at))); ?></td>
                                                            <td class="text-center align-middle text-no-wrap">
                                                                <?php echo e(number_format($item->money, 0, ',', '.')); ?> đ</td>
                                                            <td class="text-center align-middle text-no-wrap">
                                                                <?php echo e(number_format($item->money_total, 0, ',', '.')); ?> đ</td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="4"
                                                            class="text-center align-middle text-no-wrap text-bold">Chưa có
                                                            dữ liệu cho mục này</td>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div
                                        class="header-notication d-flex justify-content-between align-items-center my-3 flex-wrap flex-md-nowrap">
                                        <h2 class="title-section mb-0">Biến động Coin</h2>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th class="text-center align-middle text-no-wrap">Thời gian</th>
                                                    <th class="text-center align-middle text-no-wrap">Coin +</th>
                                                    <th class="text-center align-middle text-no-wrap">Coin -</th>
                                                    <th class="text-center align-middle text-no-wrap">Tổng</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="text-center align-middle text-no-wrap">8:00 20/07/2023</td>
                                                    <td class="text-center align-middle text-no-wrap">1.000.000đ</td>
                                                    <td class="text-center align-middle text-no-wrap">1.000.000 coin</td>
                                                    <td class="text-center align-middle text-no-wrap">1.000.000 coin</td>

                                                </tr>
                                                <tr>
                                                    <td class="text-center align-middle text-no-wrap">8:00 20/07/2023</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000đ</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000 coin</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000 coin</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center align-middle text-no-wrap">8:00 20/07/2023</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000đ</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000 coin</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000 coin</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center align-middle text-no-wrap">8:00 20/07/2023</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000đ</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000 coin</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000 coin</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center align-middle text-no-wrap">8:00 20/07/2023</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000đ</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000 coin</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000 coin</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center align-middle text-no-wrap">8:00 20/07/2023</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000đ</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000 coin</td>
                                                    <td class="text-center align-middle text-no-wrap">500.000 coin</td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center align-middle text-no-wrap">8:00 20/07/2023</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000đ</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000 coin</td>
                                                    <td class="text-center align-middle text-no-wrap">2.000.000 coin</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 col-lg-5">
             <?php if (isset($component)) { $__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Report::class, []); ?>
<?php $component->withName('report'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e)): ?>
<?php $component = $__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e; ?>
<?php unset($__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Note::class, []); ?>
<?php $component->withName('note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd)): ?>
<?php $component = $__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd; ?>
<?php unset($__componentOriginal567d7e7b45e81f44368603e5275ef9b37f4597cd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Contact::class, []); ?>
<?php $component->withName('contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed)): ?>
<?php $component = $__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed; ?>
<?php unset($__componentOriginal03f15021d0a04c246e7cfb0e08657428104723ed); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TutorialPayment::class, []); ?>
<?php $component->withName('tutorial-payment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c)): ?>
<?php $component = $__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c; ?>
<?php unset($__componentOriginal390e4705f79499b1ddfb1a8b180c8db2d9b4922c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js-before'); ?>
    <script src="<?php echo e(asset('zoom-image.js')); ?>"></script>
    <script>
        Fancybox.bind("[data-fancybox]", {});
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('copy.js')); ?>"></script>
    <script>
        CopyTextOntraffic('.text-xs-copy', 'Đã sao chép!', 1000);
    </script>
    <script>
        $('#find-history').keyup(function(e) {
            $.ajax({
                type: "POST",
                url: "<?php echo e(url('find-history')); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    value: $(this).val(),
                },
                dataType: "json",
                success: function(result) {
                    $('.history tbody').html(result);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert("Đã xảy ra lỗi khi tải dữ liệu: " + textStatus + " - " + errorThrown);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Backend\resources\views/users/payment.blade.php ENDPATH**/ ?>