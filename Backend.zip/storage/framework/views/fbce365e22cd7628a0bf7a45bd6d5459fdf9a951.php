<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ontraffic.vn - Dịch vụ tăng traffic nhanh chóng, hiệu quả</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('/client/images/fav-icon.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/bootstrap.min.css')); ?>">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css"
        integrity="sha512-ZnR2wlLbSbr8/c9AgLg3jQPAattCUImNsae6NHYnS9KrIwRdcY9DxFotXhNAKIKbAXlRnujIqUWoXXwqyFOeIQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('/animate.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/client/css/general.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/client/css/responsive.css')); ?>">
    <?php echo $__env->yieldContent('js-head'); ?>
</head>

<body>
    <div id="app" class="full-height">
        <!-- HEADER -->
        <div class="header pt-3 pb-5">
            <div class="top-sidebar">
                <div class="container pb-4">
                    <div class="row">
                        <div class="col-12 d-flex justify-content-between align-items-center">
                            <a href="<?php echo e(route('userDashboard')); ?>" class="logo-site">
                                <img src="<?php echo e(asset('/client/images/logo-ontraffic-white.png')); ?>" alt="">
                            </a>
                             <?php if (isset($component)) { $__componentOriginal43a095a4a45d198c2bb32e7d89e2e70754cd8f84 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuHeader::class, []); ?>
<?php $component->withName('menu-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal43a095a4a45d198c2bb32e7d89e2e70754cd8f84)): ?>
<?php $component = $__componentOriginal43a095a4a45d198c2bb32e7d89e2e70754cd8f84; ?>
<?php unset($__componentOriginal43a095a4a45d198c2bb32e7d89e2e70754cd8f84); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <div class="info-user d-none d-lg-block"><span class="mr-2">Hi,</span> <strong
                                    class="username ml-2"><?php echo e(Auth::user()->name); ?></strong>
                                <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                <path fill-rule="evenodd"
                                    d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
                                </svg>
                                <div class="card shadow-lg animate__animated">
                                     <?php if (isset($component)) { $__componentOriginalb50100617ffd74fbbafd645c270153dcd15297ec = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuUserHover::class, []); ?>
<?php $component->withName('menu-user-hover'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalb50100617ffd74fbbafd645c270153dcd15297ec)): ?>
<?php $component = $__componentOriginalb50100617ffd74fbbafd645c270153dcd15297ec; ?>
<?php unset($__componentOriginalb50100617ffd74fbbafd645c270153dcd15297ec); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </div>
                            </div>
                            <div class="mobile-menu-icon d-block d-lg-none">
                                <i class="bi bi-text-right"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex justify-content-between">
                        <div class="site-map">
                            <h3 class="font-bold mb-1 text-white">Hệ thống</h3>
                            <?php echo $__env->yieldContent('breadcrumb'); ?>
                        </div>
                        <div class="contact-letegram d-none d-md-block">
                            <a href="" class="btn btn-primary bd-style-2">Group Telegram</a>
                            <a href="" class="btn btn-secondary text-dark bg-white bd-style-2">Tin nhắn
                                Telegram</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- CONTENT -->
        <div class="page-content">
            <div class="content container">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <!-- SUB ELEMENT -->
        <div class="overlay"></div>
         <?php if (isset($component)) { $__componentOriginal040d42950c117c319000b3746c3804f91975a438 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MobileMenu::class, []); ?>
<?php $component->withName('mobile-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal040d42950c117c319000b3746c3804f91975a438)): ?>
<?php $component = $__componentOriginal040d42950c117c319000b3746c3804f91975a438; ?>
<?php unset($__componentOriginal040d42950c117c319000b3746c3804f91975a438); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
    <div id="online-status"></div>
    <?php echo $__env->yieldContent('js-before'); ?>
    <script src="<?php echo e(asset('/jquery-3.7.0.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/client/js/general.js')); ?>"></script>
    <script src="<?php echo e(asset('status-online.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Backend\resources\views/layouts/user.blade.php ENDPATH**/ ?>