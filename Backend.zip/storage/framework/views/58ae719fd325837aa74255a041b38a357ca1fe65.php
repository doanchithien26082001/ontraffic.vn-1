
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/client/css/dashboard.css')); ?>">
    <style>
        .form-group-password {
            position: relative;
        }

        .toggle-show-password {
            position: absolute;
            top: 2px;
            right: 18px;
            color: #6d757d;
            cursor: pointer;
            padding: 6px;
        }
        .text-xs-copy {
            cursor: pointer;
        }

        .tooltip-ontraffic {
            position: fixed;
            display: inline-block;
            background-color: rgba(0, 0, 0, 1);
            color: white;
            top: 50%;
            left: 50%;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            z-index: 9999;
        }

        .tooltip-ontraffic::before {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            border-left: 10px solid rgba(0, 0, 0, 0);
            border-top: 10px solid rgba(0, 0, 0, 1);
            border-right: 10px solid rgba(0, 0, 0, 0);
        }

        @media(max-width:280px) {

            .card-acount .info-username,
            .card-acount .coin {
                font-size: 14px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <div class="breadcrumb">
        <span class="nav-link home d-flex align-content-center"><a href="<?php echo e(route('userDashboard')); ?>"><i
                    class="bi bi-house-fill"></i> <span>Hệ thống</span></a>
        </span>
        <span class="nav-link d-flex align-content-center"><a href="<?php echo e(route('userAcount')); ?>"><i
                    class="bi bi-caret-right-fill center"></i> <span>Tài khoản</span></a>
        </span>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row gx-3">
        <div class="col-3 content-01 d-none d-lg-block">
            <div class="card shadow mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 d-flex">
                             <?php if (isset($component)) { $__componentOriginale9bdb96512e19e50217b51166c4b75315840aa29 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InfoUser01::class, []); ?>
<?php $component->withName('info-user01'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginale9bdb96512e19e50217b51166c4b75315840aa29)): ?>
<?php $component = $__componentOriginale9bdb96512e19e50217b51166c4b75315840aa29; ?>
<?php unset($__componentOriginale9bdb96512e19e50217b51166c4b75315840aa29); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <p class="text-center mb-0 level-user btn btn-primary w-100 my-3">Cấp đại lý: Khách hàng</p>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-12">
                            <ul class="list-nav-user">
                                 <?php if (isset($component)) { $__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuUser::class, []); ?>
<?php $component->withName('menu-user'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8)): ?>
<?php $component = $__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8; ?>
<?php unset($__componentOriginal5169fe5527f3432a337806f60cf2d2b2e93717e8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-9 content-02 ">
             <?php if (isset($component)) { $__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Report::class, []); ?>
<?php $component->withName('report'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e)): ?>
<?php $component = $__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e; ?>
<?php unset($__componentOriginald04fd15d528beecb55c422ca30388aba8c5be21e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <div class="card shadow-sm ">
                <div class="card-body row">
                    <p>User ID: <strong  class="text-xs-copy"><?php echo e(Auth::user()->transfer_content); ?></strong></p>
                    <div class="col-12 col-sm-6 mb-2 mb-md-0">
                        <form action="<?php echo e(route('userHandleUpdateInfo')); ?>" method="POST" class="form-auth-user">
                            <?php echo csrf_field(); ?>
                            <?php if(session('update-info')): ?>
                                <div class="form-group mt-3 register-success update-info">
                                    <p class="text-primary mb-0 fw-bold px-1 text-center"><i
                                            class="bi bi-check-circle-fill"></i>
                                        <?php echo e(session('update-info')); ?></p>
                                </div>
                            <?php endif; ?>
                            <div class="row mb-2 ">
                                <label for="inputEmail3" class="col-12 px-3 col-form-label fw-bold">Tên</label>
                                <div class="col-12 ">
                                    <input type="text" class="form-control bd-style-2" id="inputEmail3" name="name"
                                        value="<?php echo e($errors->has('name') ? old('name') : Auth::user()->name); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i
                                                class="bi bi-exclamation-circle-fill"></i>
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-2 ">
                                <label for="inputEmail3 " class="col-12 px-3 col-form-label fw-bold">Email</label>
                                <div class="col-12 ">
                                    <input type="email"class="form-control bd-style-2 " id="inputEmail3 "
                                        value="<?php echo e($errors->has('email') ? old('email') : Auth::user()->email); ?>"
                                        name="email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i
                                                class="bi bi-exclamation-circle-fill"></i>
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3 ">
                                <label for="inputEmail3 " class="col-12 px-3 col-form-label fw-bold">SĐT</label>
                                <div class="col-12 ">
                                    <input type="text" class="form-control bd-style-2 " id="inputEmail3"
                                        value="<?php echo e($errors->has('number_phone') ? old('number_phone') : Auth::user()->number_phone); ?>"
                                        name="number_phone"
                                        <?php if(Auth::user()->number_phone == null): ?> placeholder="Chưa cập nhật" <?php endif; ?>
                                        name="number_phone">
                                    <?php $__errorArgs = ['number_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i
                                                class="bi bi-exclamation-circle-fill"></i>
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-2 ">
                                <div class="col-12 ">
                                    <button type="submit" class="btn w-100 btn-primary border-0 bd-style-2 py-2">
                                        <span class="spinner-border spinner-border-sm d-none handle" role="status"
                                            aria-hidden="true"></span>
                                        <span class="text-button">Cập nhật thông tin</span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-12 col-sm-6">
                        <form action="<?php echo e(route('userHandleUpdatePassword')); ?>" method="POST" class="form-auth-user">
                            <?php echo csrf_field(); ?>
                            <?php if(session('update-password')): ?>
                                <div class="form-group mt-3 register-success update-info">
                                    <p class="text-primary mb-0 fw-bold px-1 text-center"><i
                                            class="bi bi-check-circle-fill"></i>
                                        <?php echo e(session('update-password')); ?></p>
                                </div>
                            <?php endif; ?>
                            <div class="row mb-2 ">
                                <label for="inputEmail3 " class="col-12 px-3 col-form-label fw-bold">Mật khẩu cũ</label>
                                <div class="col-12 form-group-password">
                                    <input type="password" class="form-control bd-style-2" id="inputEmail3"
                                        value="<?php echo e(session('old_password') ? '' : old('old_password')); ?>"
                                        name="old_password">
                                    <?php if(session('old_password')): ?>
                                        <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i
                                                class="bi bi-exclamation-circle-fill"></i>
                                            <?php echo e(session('old_password')); ?></p>
                                    <?php endif; ?>
                                    <span class="toggle-show-password">
                                        <i class="bi bi-eye-fill"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="row mb-2 ">
                                <label for="inputEmail3" class="col-12 px-3 col-form-label fw-bold">Mật khẩu mới</label>
                                <div class="col-12 form-group-password">
                                    <input type="password" class="form-control bd-style-2 " id="inputEmail3 "
                                        name="password">
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i
                                                class="bi bi-exclamation-circle-fill"></i>
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <span class="toggle-show-password">
                                        <i class="bi bi-eye-fill"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="row mb-3 ">
                                <label for="inputEmail3 " class="col-12 px-3 col-form-label fw-bold">Nhập lại mật
                                    khẩu</label>
                                <div class="col-12 form-group-password">
                                    <input type="password " class="form-control bd-style-2 " id="inputEmail3"
                                        name="password_confirmation">
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-primary mb-0 fw-bold px-1 mt-2 form-error"><i
                                                class="bi bi-exclamation-circle-fill"></i>
                                            <?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <span class="toggle-show-password">
                                        <i class="bi bi-eye-fill"></i>
                                    </span>
                                </div>
                            </div>
                            <div class="row mb-2 ">
                                <div class="col-12 ">
                                    <button type="submit" class="btn w-100 btn-primary border-0 bd-style-2 py-2">
                                        <span class="spinner-border spinner-border-sm d-none handle" role="status"
                                            aria-hidden="true"></span>
                                        <span class="text-button">Đặt lại mật khẩu</span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('client/js/auth-user.js')); ?>"></script>
    <script src="<?php echo e(asset('copy.js')); ?>"></script>
    <script>
        CopyTextOntraffic('.text-xs-copy', 'Đã sao chép!', 1000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Backend\resources\views/users/acount.blade.php ENDPATH**/ ?>