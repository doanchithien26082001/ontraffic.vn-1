<div class="card shadow-sm mb-3">
    <div class="card-body">
        <div class="header-notication d-flex justify-content-between align-items-center mb-3">
            <h2 class="title-section mb-0">Lưu ý</h2>
        </div>
        <ul>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Nạp sai cú pháp hoặc sai số tài
                khoản sẽ bị trừ 10% phí giao dịch, tối đa trừ 50.000 mCoin. Ví dụ nạp sai 100.000 trừ 10.000,
                200.000 trừ 20.000 , 500.000 trừ 50.000, 1 triệu trừ
                50.000, 10 triệu trừ 50.000...</li>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Buổi tối 18-24h Vietcombank
                thường tổng kết các giao dịch trong ngày nên thường chậm và lag.</li>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Do đó chuyển khoản vào thời gian
                này có thể bị auto nạp chậm, sau vài tiếng mới nhận được tiền.</li>
            <li class="text-dark mb-2"><i class="bi bi-caret-right-fill"></i> Các bạn nên ưu tiên chuyển vào
                ban ngày để nhận tiền nhanh nhất nhé.</li>
        </ul>
    </div>
</div>