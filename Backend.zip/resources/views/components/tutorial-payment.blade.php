<div class="card shadow-sm mb-3">
    <div class="card-body">
        <div class="header-notication d-flex justify-content-between align-items-center mb-3">
            <h2 class="title-section mb-0">Hướng dẫn thanh toán</h2>
        </div>
        <iframe class="bd-style-1" width="100%" height="300px"
            src="https://www.youtube.com/embed/WWqKord6tEA" title="YouTube video player" frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen></iframe>
    </div>
</div>